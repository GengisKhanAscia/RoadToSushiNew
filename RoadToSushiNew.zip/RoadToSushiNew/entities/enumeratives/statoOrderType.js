const statoOrderType = {
    INVIATO: 'In preparazione',
    PRONTO: 'Pronto',
}

module.exports = statoOrderType;